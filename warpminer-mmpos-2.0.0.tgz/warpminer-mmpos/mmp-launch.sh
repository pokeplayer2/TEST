#!/usr/bin/env bash
# mmpOS launcher: WarpMiner -> externe FusionLayer-Node
#   Pool-Feld in mmpOS = IP:Port deiner Node, z.B. 192.168.10.5:8546
set -u
cd "$(dirname "$0")"
POOL_HOST=""; POOL_PORT="8546"; USER_ARG=""; PASS_ARG="x"; EXTRA=()
while [[ $# -gt 0 ]]; do
  case "$1" in
    --coin) shift 2;;
    --pool) POOL_HOST="${2%%:*}"; POOL_PORT="${2##*:}"; shift 2;;
    --user) USER_ARG="$2"; shift 2;;
    --password) PASS_ARG="$2"; shift 2;;
    --api-port) shift 2;;
    *) EXTRA+=("$1"); shift;;
  esac
done
trap 'while killall warpminer >/dev/null 2>&1; do sleep 1; done; exit 0' SIGTERM SIGINT
echo "[mmp-launch] warpminer -> ws://${POOL_HOST}:${POOL_PORT}  (user=${USER_ARG})"
./warpminer -pool "ws://${POOL_HOST}:${POOL_PORT}" -user "$USER_ARG" -pass "$PASS_ARG" "${EXTRA[@]}" &
wait $!
while killall warpminer >/dev/null 2>&1; do sleep 1; done
