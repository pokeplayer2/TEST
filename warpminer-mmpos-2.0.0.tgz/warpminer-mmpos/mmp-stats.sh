#!/usr/bin/env bash
DEVICE_NUM=$1; LOG_FILE=$2
[[ -r "$LOG_FILE" ]] || { echo "Miner is starting"; exit 0; }
mapfile -t IDX < <(grep -oE 'Device \[[0-9]+\] hashRate' "$LOG_FILE" 2>/dev/null | grep -oE '[0-9]+' | sort -n | uniq)
HASH=()
for i in "${IDX[@]}"; do
  v=$(grep -E "Device \[$i\] hashRate:" "$LOG_FILE" 2>/dev/null | tail -1 | grep -oE '[0-9]+\.[0-9]+' | tail -1)
  [[ -z "$v" ]] && v="0"; HASH+=("$v")
done
N=${#HASH[@]}; [[ $N -eq 0 ]] && { echo "Miner is starting"; exit 0; }
BUS=(); GI=/run/gpu-info.json
if [[ -r "$GI" ]]; then
  while read -r b; do [[ -z "$b" ]] && continue; hex=${b:5:2}; BUS+=( $((16#$hex)) ); done \
    < <(jq -r '(.device.GPU.nvidia_details.busid[]?),(.device.GPU.amd_sysfs_details.busid[]?)' "$GI" 2>/dev/null)
fi
[[ ${#BUS[@]} -ne $N ]] && BUS=( $(seq 1 "$N") )
ACC=$(grep -c "Solutions accepted" "$LOG_FILE" 2>/dev/null); ACC=${ACC:-0}
REJ=$(grep -c "Solutions rejected" "$LOG_FILE" 2>/dev/null); REJ=${REJ:-0}
jq -nc --argjson busid "$(printf '%s\n' "${BUS[@]}"|jq -sc .)" --argjson hash "$(printf '%s\n' "${HASH[@]}"|jq -sc .)" \
  --arg acc "$ACC" --arg rej "$REJ" \
  '{busid:$busid,hash:$hash,units:"khs",air:[$acc,"0",$rej],miner_name:"warpminer",miner_version:"2.0.0"}'
